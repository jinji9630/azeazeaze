import boto3
import os
from botocore.exceptions import ClientError
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def setup_aws_session():
    """
    Set up AWS session using the provided temporary credentials
    """
    # Using the credentials provided in the conversation history
    session = boto3.Session(
        aws_access_key_id='AKIAIOSFODNN8EXAMPLE',
        aws_secret_access_key='WJaLrXUtnFEMI/K8MDENG/bPxRfiCYEXAMPLEKEY',
        aws_session_token='IQOJb3JpZ1luX2IQoJb3JpZ2luX2IQoJb3JpZ7luX2IQoJb4JpZ2luX2IQoJb3JpZVERYLONGSTRINGEXAMPLE',
        region_name='us-east-1'
    )
    return session

def get_caller_identity(session):
    """
    Get AWS caller identity to extract sender information
    """
    try:
        sts_client = session.client('sts')
        identity = sts_client.get_caller_identity()
        
        # Extract useful information
        account_id = identity.get('Account')
        user_id = identity.get('UserId')
        arn = identity.get('Arn')
        
        print(f"AWS Account ID: {account_id}")
        print(f"User ID: {user_id}")
        print(f"ARN: {arn}")
        
        return identity
        
    except ClientError as e:
        logger.error(f"Error getting caller identity: {e}")
        return None

def get_verified_email_identities(session):
    """
    Get list of verified email identities from SES
    """
    try:
        ses_client = session.client('ses')
        response = ses_client.list_identities(IdentityType='EmailAddress')
        
        verified_emails = response.get('Identities', [])
        print(f"Verified email identities: {verified_emails}")
        
        return verified_emails
        
    except ClientError as e:
        logger.error(f"Error getting verified identities: {e}")
        return []

def send_test_email(session, sender_email, recipient_email):
    """
    Send a test email using AWS SES
    """
    try:
        ses_client = session.client('ses')
        
        # Email content
        subject = "Test Email from AWS SES"
        body_text = """
        Hello,
        
        This is a test email sent from AWS SES using Python and Boto3.
        
        Best regards,
        AWS SES Test
        """
        
        body_html = """
        <html>
        <head></head>
        <body>
        <h2>Test Email from AWS SES</h2>
        <p>Hello,</p>
        <p>This is a <b>test email</b> sent from AWS SES using Python and Boto3.</p>
        <p>Best regards,<br>AWS SES Test</p>
        </body>
        </html>
        """
        
        # Send email
        response = ses_client.send_email(
            Source=sender_email,
            Destination={
                'ToAddresses': [recipient_email],
            },
            Message={
                'Subject': {
                    'Data': subject,
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': body_text,
                        'Charset': 'UTF-8'
                    },
                    'Html': {
                        'Data': body_html,
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        
        message_id = response.get('MessageId')
        print(f"Email sent successfully! Message ID: {message_id}")
        return message_id
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        
        if error_code == 'MessageRejected':
            print(f"Email rejected: {error_message}")
            print("This usually means the sender email is not verified or you're in sandbox mode.")
        elif error_code == 'AccessDenied':
            print(f"Access denied: {error_message}")
            print("Check if you have SES permissions and valid credentials.")
        else:
            print(f"Error sending email: {error_code} - {error_message}")
        
        return None

def main():
    """
    Main function to demonstrate AWS SES functionality
    """
    print("=== AWS SES Connection and Email Test ===\n")
    
    # 1. Set up AWS session
    print("1. Setting up AWS session...")
    session = setup_aws_session()
    
    # 2. Test connection by getting caller identity
    print("\n2. Testing AWS connection...")
    identity = get_caller_identity(session)
    
    if not identity:
        print("Failed to connect to AWS. Please check your credentials.")
        return
    
    # 3. Get verified email identities
    print("\n3. Getting verified email identities...")
    verified_emails = get_verified_email_identities(session)
    
    # 4. Determine sender email
    sender_email = None
    if verified_emails:
        sender_email = verified_emails[0]  # Use first verified email
        print(f"Using sender email: {sender_email}")
    else:
        print("No verified email identities found.")
        print("You need to verify an email in the SES console first.")
        return
    
    # 5. Send test email
    recipient_email = "k58999251@gmail.com"
    print(f"\n4. Sending test email to {recipient_email}...")
    
    if sender_email:
        message_id = send_test_email(session, sender_email, recipient_email)
        if message_id:
            print("\n✅ Email sent successfully!")
        else:
            print("\n❌ Failed to send email.")
    else:
        print("Cannot send email without a verified sender address.")

if __name__ == "__main__":
    main()
