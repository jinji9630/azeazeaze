The file was downloaded from https://domains-monitor.com - portal with lists of all domains on the Internet, newly registered/deleted domains in all zones and related services.

Domains Monitor is:
- The most complete list of registered domains on the Internet.
- Updated daily with newly registered and deleted domains.
- Detailed list of domains with E-mails,phones and additional information.
- Support of 1 570 domain zones.
- Search tool for all domain names on the Internet.
- Monitoring and notification tool for newly registered and deleted domains.
- List of websites with certain technologies(CMS, analytic service, framework, ad platform, etc).
- Database of all DNS TXT records for all domains.
- API for data access.
- Lowest price with unlimited access.

https://domains-monitor.com
Enjoy!
